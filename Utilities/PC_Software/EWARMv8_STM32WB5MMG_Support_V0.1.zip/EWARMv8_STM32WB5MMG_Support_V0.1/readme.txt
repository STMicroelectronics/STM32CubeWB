/******************** (C) COPYRIGHT 2020 STMicroelectronics ********************************
* File Name          : readme.txt
* Author             : STMicroelectronics
* Version            : V0.1
* Date               : 05/02/2020
* Description        : This file describes how to add STM32WB5MMG device support on EWARM 
********************************************************************************************

Running the "EWARMv8_STM32WB5MMG_Support_V0.1.exe" adds the following:
  
1. Part numbers for: STM32WB5MMG

2. Automatic STM32WB5MMG flash algorithm selection

3. SVD file


How to use:
==========
* Before installing the files mentioned above, you need to have EWARM v8.xx 
or later installed. 
You can download EWARM from IAR web site @ www.iar.com
 
* Run "EWARMv8_STM32WB5MMG_Support_V0.1.exe"  at EWARM install directory.
EWARM Install Directory is set by default to "C:\Program Files\IAR Systems\Embedded Workbench \", 
please change it manually if you have EWARM installed at different location.

******************* (C) COPYRIGHT 2019 STMicroelectronics *****END OF FILE***************





	



