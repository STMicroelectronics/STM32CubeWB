/**
  ************************************************************************************************
  * @file    readme.txt 
  * @author  MCD Application Team
  * @brief   Description of  how to add STM32WB1x devices support on EWARM.
  ************************************************************************************************
  * @attention
  *
  * Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  *************************************************************************************************/
These packages contains the needed files to be installed in order to support STM32WB1x 
devices by EWARM8 and laters.

1. If you have already installed an STM32WB1x patch before, you can remove it by running 
Uninstall_Patch.bat (run as administrator).

2. Running the "EWARMv8_STM32WB1x_V1.1.1.exe" adds the following:
=====================================================================
 1. Part numbers for  :
	- Product lines with 320kB flash size:STM32WB10xC/STM32WB15xC/STM32WB1MxC
 
 - Automatic STM32WB1x flash algorithm selection
 
 - SVD file  


How to use:
==========
* Before installing the files mentioned above, you need to have EWARM v8.xx or later installed. 
You can download EWARM from IAR web site @ www.iar.com
 
* Run "EWARMv8_STM32WB1x_V1.1.1.exe"  at EWARM install directory.
EWARM Install Directory is set by default to "C:\Program Files\IAR Systems\Embedded Workbench \", 
please change it manually if you have EWARM installed at different location. 