/******************** (C) COPYRIGHT 2020 STMicroelectronics **************************************
* File Name          : readme.txt
* Author             : STMicroelectronics
* Version            : V0.0.1
* Date               : 17/04/2020
* Description        : This file describes how to add STM32WB15x devices support on MDK-ARM 
**************************************************************************************************

Running the "Keil.STM32WB15x_DFP.0.0.1.pack" adds the following:
  
1. Part numbers for  :
  - Product lines: STM32WB15CCxx
  - Value Line : STM32WB10CCxx               

2. Automatic STM32WB15 flash algorithm selection 
    
3. SVD file


How to use:
==========
* Before installing the files mentioned above, you need to have MDK-ARM v5.25 
or later installed. 
You can download pack from keil web site @ www.keil.com
 
* Double Clic on  "Keil.STM32WB15x_DFP.0.0.1.pack" in order to install this pack in 
the Keil install directory.

******************* (C) COPYRIGHT 2019 STMicroelectronics *****END OF FILE************************





	



