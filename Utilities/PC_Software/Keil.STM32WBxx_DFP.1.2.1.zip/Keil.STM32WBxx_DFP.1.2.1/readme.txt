/**
  ************************************************************************************************
  * @file    readme.txt 
  * @author  MCD Application Team
  * @brief   Description of  how to add STM32WB devices support on MDK-ARM.
  ************************************************************************************************
  * @attention
  *
  * Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  *************************************************************************************************/

Running the "Keil.STM32WBxx_DFP.1.2.1.pack" adds the following:
  
1. Part numbers for  :
  - Product lines: STM32WB55xGxx/ STM32WB55xExx/ STM32WB55xCxx/ STM32WB35xCxx/STM32WB35xExx/ STM32WB55xYxx/ STM32WB15xCxx/STM32WB5MxGxx/STM32WB1MMCHx
  - Value Line : STM32WB50xGxx, STM32WB30xExx, STM32WB10xCxx

2. Automatic STM32WB flash algorithm selection 
    
3. SVD file for STM32WB.


How to use:
==========
* Before installing the files mentioned above, you need to have MDK-ARM v5.25 
or later installed. 
You can download pack from keil web site @ www.keil.com
 
* Double Clic on  "Keil.STM32WBxx_DFP.1.2.1.pack" in order to install this pack in 
the Keil install directory.






	



