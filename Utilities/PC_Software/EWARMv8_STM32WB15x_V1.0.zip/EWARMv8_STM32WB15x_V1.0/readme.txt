/**
  ************************************************************************************************
  * @file    readme.txt 
  * @author  MCD Application Team
  * @brief   Description of  how to add STM32WB15x devices support on EWARM.
  ************************************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2021 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under Ultimate Liberty license
  * SLA0044, the "License"; You may not use this file except in compliance with
  * the License. You may obtain a copy of the License at:
  *                      www.st.com/SLA0044
  *
  *************************************************************************************************/
  These packages contains the needed files to be installed in order to support STM32WB15x 
  devices by EWARM8 and laters.

    Running the "EWARMv8_STM32WB15x_V1.0.exe" (Signed Official patch) adds the following:
   =======================================================================================
  
  - Part numbers with 320kB Flash size : STM32WB15CC
  - Value Line with 320kB Flash size   : STM32WB10CC 
  - Automatic STM32WB15 flash algorithm selection 
  - STM32WB15xx and STM32WB10xx SVD files              


How to use:
==========
* Before installing the files mentioned above, you need to have EWARM v8.xx or later installed. 
You can download EWARM from IAR web site @ www.iar.com
 
* Run "EWARMv8_STM32WB15x_V1.0.exe"  as administrator on EWARM install directory.
Ewarm Install Directory is "C:\Program Files\IAR Systems\Embedded Workbench \",


******************* (C) COPYRIGHT 2021 STMicroelectronics *****END OF FILE***************





	



