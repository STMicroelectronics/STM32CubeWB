/******************** (C) COPYRIGHT 2020 STMicroelectronics ********************************
* File Name          : readme.txt
* Author             : STMicroelectronics
* Version            : V0.2
* Date               : 17/03/2020
* Description        : This file describes how to add STM32WB15x devices  support on EWARM 
********************************************************************************************

Running the "EWARMv8_STM32WB15x_Support_V0.2.exe" adds the following:
  
1. Part numbers for:
- Product lines: STM32WB15CC
- Value Line: STM32WB10CC               

2. Automatic STM32WB15 flash algorithm selection

3. SVD file.


How to use:
==========
* Before installing the files mentioned above, you need to have EWARM v8.xx 
or later installed. 
You can download EWARM from IAR web site @ www.iar.com
 
* Run "EWARMv8_STM32WB15x_Support_V0.2.exe"  at EWARM install directory.
EWARM Install Directory is set by default to "C:\Program Files\IAR Systems\Embedded Workbench \", 
please change it manually if you have EWARM installed at different location.

******************* (C) COPYRIGHT 2019 STMicroelectronics *****END OF FILE***************





	



